# Script Object
Small library to add similar functionality to all scripts